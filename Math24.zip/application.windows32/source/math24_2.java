import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.File; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class math24_2 extends PApplet {

/*------------------------
 MATH 24 Challenge Game
 By: Ryan Wilk
 Last Update: 6/9/15
 
 Notes:
 -fix lives
 -add main menu
 --move mode to home screen (call it solver)
 --back to main menu button
 --options button
 --single player button
 --high score button
 -add graphics
 -----------------------*/


//Game Parameters
int maxRand=0;
int amtNumbers=0;
int midPoint=6;
int highPoint=12;
int maxTime=0;
int screenW=800;
int screenH=600;
int bgColor=color(0, 0, 0);

//Control Variables
int combLength=0;
int selectedSymbol=0;
int selectedNum=0;
int ansNum=0;
int numLives=0;
boolean solverMode=false;
boolean displayAnswer=false;
boolean gameOver=false;
boolean correctAnswer=false;

//Mass storage Variables
ArrayList<String[]> combinations=new ArrayList<String[]>();
ArrayList<int[]> permutations=new ArrayList<int[]>();
StringList answers=new StringList();

//Game Controls
ArrayList <Object>nums=new ArrayList<Object>();
ArrayList <Life>lives=new ArrayList<Life>();
Symbol [] operation=new Symbol[4];
Button next, mode, undo;
Score scoreSys;

public void settings() {
   size(screenW, screenH); 
}

public void setup() {
  importSettings();
  surface.setTitle("24 Challenge");
  surface.setResizable(true);
  for (int i=0; i<amtNumbers; i++)
    nums.add(new Object(i+1));
  char[] symb = new char[] {
    '+', '-', 'x', '\u00f7'
  };
  combinate("", symb);
  for (int i=0; i<operation.length; i++)
    operation[i]=new Symbol(symb[i], i+1);
  for (int i=0; i<numLives;i++)
    lives.add(new Life(i+1));
  makeRandNums();
  next=new Button("Next", 1);
  mode=new Button("Mode", 2);
  undo=new Button("\u21BA", 3);
  scoreSys=new Score();
}

public void draw() {
  if (correctAnswer)
    bgColor=color(0, 255, 0);
  background(bgColor);
  if (!gameOver) {
    if (!solverMode) {
      drawSymbols();
      drawLives();
      scoreSys.run();
    }
    if (displayAnswer&&!correctAnswer)
      drawAnswer();
    drawNums();
    drawButtons();
  }
  else text("GAME OVER", width/2, height/2);
}

public void importSettings() {
  //Get saved settings from settings.ini
  File settingsLoc=new File(sketchPath("settings.ini"));
  String settings="";

  if (settingsLoc.exists()) {
    String input[]=loadStrings("settings.ini");
    for (int i=0;i<input.length;i++)
      settings+=input[i];
    maxRand=Integer.parseInt(settings.substring(settings.indexOf("maxRand=")+8, settings.indexOf("amtNumbers")));
    amtNumbers=Integer.parseInt(settings.substring(settings.indexOf("amtNumbers=")+11, settings.indexOf("maxTime")));
    maxTime=Integer.parseInt(settings.substring(settings.indexOf("maxTime=")+8, settings.indexOf("numLives")));
    numLives=Integer.parseInt(settings.substring(settings.indexOf("numLives=")+9));
    if (amtNumbers>6)
      amtNumbers=6;

    combLength=amtNumbers-1;
  }
  else println("ERROR: missing settings.ini file");
}

public void drawSymbols() {
  //Draw all the math operation buttons
  fill(255, 200);
  noStroke();
  ellipse(width/2, 4*height/6, operation[3].x-operation[2].x, operation[1].y-operation[0].y);
  operation[0].run(width/2, 3*height/6);
  operation[1].run(width/2, 5*height/6);
  operation[2].run(width/2-operation[2].s, 4*height/6);
  operation[3].run(width/2+operation[2].s, 4*height/6);
}

public void drawButtons() {
  //Draw game control buttons
  mode.run(width-75, height-50);
  if (!solverMode) {
    next.run(75, height-50);
    undo.run(width-75, 50);
  }
}

public void drawLives() {
  textSize(18);
  fill(255);
  text("Lives:", 50, 125);
  if (lives.size()==0)
    gameOver=true;
  else {
    for (int i=0;i<lives.size();i++)
      lives.get(i).run(50, 150+65*i);
  }
}

public void makeRandNums() {
  //Create random numbers, then do math to check for 24
  for (int i=0; i<nums.size(); i++) {
    nums.get(i).origValue=(int)random(0, maxRand);
    nums.get(i).value=nums.get(i).origValue;
  }
  compute();
}

public void drawNums() {
  //Draw the number objects
  for (int i=0; i<nums.size(); i++)
    nums.get(i).run(nums.get(i).xSpacing*(i+1), nums.get(i).s);
}

public void drawAnswer() {
  //Display answer when displayAnswer=true
  //n sets the location of where to display the answer vertically
  int n=0;
  if (solverMode) {
    n=2;
  } 
  else {
    n=3;
  }
  textAlign(CENTER);
  fill(255);
  textSize(18);
  text("ANSWER:", 100, 100);
  if (answers.size()>0)
    text(answers.get(ansNum), width/2, height/n);
  else text("No Possible Solution", width/2, height/n);
}

public void resetPermutations() {
  //clears all saved information from previous number set
  //Runs at the begining of compute() and therefore anytime random numbers are made
  for (int i=0; i<nums.size(); i++)
    nums.get(i).display=true;
  answers.clear();
  permutations.clear();
  correctAnswer=false;
}

public void restart() {
  scoreSys.score=0;
  gameOver=false; 
  for (int i=0; i<numLives;i++)
    lives.add(new Life(i+1));
}
class Object {
  int x;
  int y;
  int s=70;
  int xSpacing=(width-300)/amtNumbers;
  int ident;
  boolean display=true;
  int origValue;
  float value;
  String displayValue="_";
  Object(int _ident) {
    ident=_ident;
  }

  public void run(int _x, int _y) {
    x=_x;
    y=_y;
    if (display) {
      if (!solverMode) {
        value2displayValue();
        display();
      } 
      else {
        displayValue2Value();
        display();
      }
    }
  }  

  public void display() {
    if (selectedNum==ident)
      fill(255);
    else
      noFill();
    rectMode(CENTER);
    if (mouseOver())
      stroke(255);
    else noStroke();
    rect(x, y-s/4, s, s);
    if (selectedNum==ident)
      fill(0);
    else
      fill(255);
    textSize(s-10);
    text(displayValue, x, y);
  }

  public void value2displayValue() {
    if (value%1==0) {
      String hold=str(value);
      if (hold.indexOf(".")<0)
        displayValue=hold;
      else displayValue=hold.substring(0, hold.indexOf("."));
    } 
    else {
      if (value%.5f==0)
        displayValue=nf(value, 1, 1);
      else displayValue=nf(value, 1, 2);
    }
  }

  public void displayValue2Value() {
    if (!displayValue.equals("_")&&displayValue.length()>0)
      value=Float.parseFloat(displayValue);

    if (selectedNum!=ident&&displayValue.length()==0)
      displayValue="_";
  }

  public boolean mouseOver() {
    if (mouseX>x-s/2&&mouseX<x+s/2&&mouseY>y-s/2-10&&mouseY<y+s/2-10&&display)
      return true;
    else
      return false;
  }

  public void click() {
    if (mouseOver()&&selectedNum!=ident) {
      if (solverMode) {
        selectedNum=ident;
        displayValue="";
      } 
      else {
        if (selectedNum>0&&selectedSymbol>0) {
          doMath(ident, value);
        } 
        else
          selectedNum=ident;
        checkFor24();
      }
    }
  }
}

public boolean mouseOverNums() {
  int token=0;
  for (int i=0; i<nums.size(); i++)
    if (nums.get(i).mouseOver())
      token++;

  if (token>0)
    return true;
  else return false;
}

public void doMath(int n, float numberValue) {
  //Computes individual operation. Sends to applyMathResult() to save new values
  FloatList pass=new FloatList();
  float ans=0;
  int x=0;
  for (int i=0; i<nums.size(); i++) {
    if (nums.get(i).display) {
      pass.append(nums.get(x).value);
      x++;
    }
  }
  if (selectedSymbol==1) {
    ans=nums.get(selectedNum-1).value+numberValue;
  } 
  else if (selectedSymbol==2) {
    ans=nums.get(selectedNum-1).value-numberValue;
  } 
  else if (selectedSymbol==3) {
    ans=nums.get(selectedNum-1).value*numberValue;
  } 
  else if (selectedSymbol==4) {
    if (numberValue!=0) {
      ans=nums.get(selectedNum-1).value/numberValue;
    } 
    else println("Cannot Divide By 0");
  }
  pass.set(n-1, ans);
  pass.remove(selectedNum-1);
  println(nums.get(selectedNum-1).value+" "+operation[selectedSymbol-1].name+" "+numberValue+" = "+ans);
  applyMathResult(pass.array());

  selectedNum=0;
  selectedSymbol=0;
}


public void applyMathResult(float [] newValue) {
  //Applies new values for the calculated math results in doMath()
  for (int i=0; i<newValue.length; i++)
    nums.get(i).value=newValue[i];

  for (int i=newValue.length; i<nums.size(); i++)
    nums.get(i).display=false;
}

public boolean testForCompleteSolver() {
  //Tests that no blank spaces exist in solver mode
  int token=0;
  for (int i=0; i<nums.size(); i++)
    if (nums.get(i).displayValue.equals("_")||nums.get(i).displayValue.equals(""))
      token++;

  if (token==0) {
    return true;
  } 
  else
    return false;
}

public void checkFor24() {
  //Check that there is 1 number object turned on and that it is indeed 24
  //If 24, display correct answer screen, record times, add score
  int token=0;
  for (int i=0; i<nums.size(); i++)
    if (nums.get(i).display)
      token++;

  if (token==1&&nums.get(0).value==24&&!correctAnswer&&!displayAnswer) {
    correctAnswer=true;
    scoreSys.holdTime=maxTime-(millis()-scoreSys.prevTime)/1000;
    scoreSys.prevTime=millis()-scoreSys.prevTime;
    scoreSys.score+=scoreSys.holdTime*scoreSys.multiplier;
  }
  else if (displayAnswer&&!correctAnswer)
    lives.remove(lives.size()-1);
}
class Symbol {
  char name;
  int ident;
  int s=100;
  int x, y;
  int clickColor=color(255);
  int staticColor=color(100);
  Symbol(char _name, int _ident) {
    name=_name;
    ident=_ident;
  }

  public void run(int _x, int _y) {
    x=_x;
    y=_y;
    display();
  }

  public void display() {
    if (selectedSymbol==ident)
      fill(clickColor);
    else
      fill(staticColor);
    rectMode(CENTER);
    if (mouseOver())
      stroke(255);
    else stroke(0);
    rect(x, y, s, s);
    textSize(s/2);
    textAlign(CENTER);
    fill(0);
    text(name, x+2, y+10+2);
    fill(255, 0, 0);
    text(name, x, y+10);
  }

  public boolean mouseOver() {
    if (mouseX>x-s/2&&mouseX<x+s/2&&mouseY>y-s/2&&mouseY<y+s/2&&!solverMode)
      return true;
    else
      return false;
  }

  public void click() {
    if (mouseOver()&&!displayAnswer) {
      if (selectedSymbol==ident) {
        XthemAll(selectedSymbol);
        selectedSymbol=0;
      } 
      else
        selectedSymbol=ident;
    }
  }
}

public boolean mouseOverSymbols() {
  int token=0;
  for (int i=0; i<operation.length; i++)
    if (operation[i].mouseOver())
      token++;

  if (token>0) 
    return true;
  else return false;
}

public void XthemAll(int symbol) {
  //Applies math operation to all remaining numbers if double clicked
  FloatList save=new FloatList();
  for (int i=0; i<nums.size(); i++)
    if (nums.get(i).display)
      save.append(nums.get(i).value);

  float result=save.get(0);
  switch(symbol) {

  case 1: 
    {
      println("Add remaining numbers");
      for (int i=1; i<save.size (); i++)
        result+=save.get(i);
      break;
    }
  case 2: 
    {
      println("Subtract remaining numbers");
      for (int i=1; i<save.size (); i++)
        result-=save.get(i);
      break;
    }
  case 3: 
    {
      println("Multiply remaining numbers");
      for (int i=1; i<save.size (); i++)
        result*=save.get(i);
      break;
    }
  case 4: 
    {
      println("Divide remaining numbers");
      int token=0;
      for (int i=0; i<save.size (); i++)
        if (save.get(i)==0)
          token++;

      if (token==0)   
        for (int i=1; i<save.size (); i++)
          result/=save.get(i);
      else result=0;
      break;
    }
  }
  println(result);
  if (result!=0) {
    for (int i=1; i<nums.size(); i++)
      nums.get(i).display=false;
    nums.get(0).value=result;
    checkFor24();
  }
}
//--------------------------------------------------------------

class Button {
  String name;
  int ident;
  int s=50;
  int x, y;
  Button(String _name, int _ident) {
    name=_name;
    ident=_ident;
  }
  public void run(int _x, int _y) {
    x=_x;
    y=_y;
    display();
  }

  public void display() {
    fill(0, 0, 255);
    if (mouseOver())
      stroke(255);
    else stroke(0);
    ellipseMode(CENTER);
    ellipse(x, y, s, s);
    textAlign(CENTER);
    fill(255);
    if (ident==3) {
      textSize(35);
      text(name, x, y+12);
    } 
    else {
      textSize(20);
      text(name, x, y+5);
    }
  }

  public boolean mouseOver() {
    if (sqrt(sq(x-mouseX) + sq(y-mouseY)) < s/2 )
      return true;
    else
      return false;
  }

  public void click() {
    if (mouseOver()) {
      selectedNum=-1;
      selectedSymbol=0;
      switch (ident) {
      case 1: //Next Button
        {
          bgColor=0;
          makeRandNums();
          displayAnswer=false;
          scoreSys.prevTime=millis();
          break;
        } 
      case 2: //Mode Button
        {
          solverMode=!solverMode;
          bgColor=0;
          scoreSys.prevTime=millis();
          displayAnswer=false;
          if (solverMode==false) {
            println("Game Mode");
            makeRandNums();
          } 
          else {
            println("Solver Mode");
            resetPermutations();
            for (int i=0; i<nums.size(); i++) {
              nums.get(i).displayValue="_";
              nums.get(i).displayValue2Value();
            }
          }
          break;
        }
      case 3: //Undo Button
        {
          if (!correctAnswer) {
            for (int i=0; i<nums.size(); i++) {
              nums.get(i).value=nums.get(i).origValue;
              nums.get(i).display=true;
            }
          }
          break;
        }
      }
    }
  }
}
//---------------------------------------------------------
//-------------------------------------------------------------
//Create initial combinations of math operations
public void combinate(String save, char[] symb) {
  if (save.length() == combLength) {
    break2array(save);
  } else {
    for (int i = 0; i < symb.length; i++) {
      String oldCurr = save;
      save += symb[i];
      combinate(save, symb);
      save = oldCurr;
    }
  }
}

public void break2array(String comb) {
  String [] hold= new String [combLength];
  for (int i=0; i<hold.length; i++)
    hold[i]=comb.substring(i, i+1);
  combinations.add(hold);
}

public void outputCombinations() {
  for (int i=0; i<combinations.size (); i++) {
    println(combinations.get(i));
  }
}

//--------------------------------------------------------------
//Calculate all math Permutations and check for 24
public void compute() {
  int []holdNum=new int[0];
  int []startNum=new int [nums.size()];
  resetPermutations();
  //Get all starting numbers in an array
  for (int i=0; i<nums.size(); i++)
    startNum[i]=(int)nums.get(i).value;

  //Find all permutations
  permutate(holdNum, startNum);

  //Do the math combining the permutations & combinations
  for (int i=0; i<combinations.size (); i++)
    for (int j=0; j<permutations.size (); j++) {
      math(i, j);
    }

  //If there are no solutions, output those values and run again
  if (answers.size()==0&&!solverMode) {
    for (int i=0; i<nums.size(); i++)
      println(nums.get(i).value);
    println("--------------");
    makeRandNums();
  } else {
    println(answers.size());
    ansNum=(int)random(0, answers.size()-1);
    println(ansNum+":"+answers.size());
  }
}

public void permutate(int[] save, int[] values) {
  int n = values.length;
  if (n == 0) 
    permutations.add(save);
  else {
    for (int i = 0; i < n; i++)
      permutate(include(save, values[i]), nextArray(values, i));
  }
}

public int [] include(int [] y, int addon) {
  int [] store=new int [y.length+1];
  for (int i=0; i<y.length; i++)
    store[i]=y[i];
  store[y.length]=addon;
  return store;
}

public int [] nextArray(int[] x, int n) {
  IntList next=new IntList();
  for (int i=0; i<n; i++) {
    next.append(x[i]);
  }
  for (int j=n+1; j<x.length; j++) {
    next.append(x[j]);
  }
  return next.array();
}

public void outputPermutations() {
  for (int i=0; i<permutations.size (); i++) {
    for (int j=0; j<4; j++)
      print(permutations.get(i)[j]);
    println("");
  }
}

//------------------------------------------------------
//Finds all possible solutions and saves the good ones
public void math(int com, int perm) {
  String outputAnswer="";
  float [] number=new float [nums.size()];
  String [] sign=new String [combLength];
  String [] store=new String [nums.size()];

  for (int i=0; i<nums.size(); i++) {
    number[i]=permutations.get(perm)[i];
    store[i]=str(number[i]);
  }
  for (int i=0; i<combLength; i++)
    sign[i]=combinations.get(com)[i];

  for (int i=0; i<sign.length; i++)
    if (sign[i].equals("+"))
      number[i+1]=number[i]+number[i+1];
    else if (sign[i].equals("-"))
      number[i+1]=number[i]-number[i+1];
    else if (sign[i].equals("x"))
      number[i+1]=number[i]*number[i+1];
    else if (sign[i].equals("\u00f7"))
      if (number[i+1]!=0)
        number[i+1]=number[i]/number[i+1];

  if (number[nums.size()-1]==24.0f) {
    for (int i=0; i<sign.length; i++)
      outputAnswer+=store[i]+sign[i];
    answers.append(outputAnswer+store[nums.size()-1]+"="+number[nums.size()-1]);
  }
}
class Score {
  float prevTime=0;
  float holdTime=0;
  int score=0;
  int multiplier=1;
  Score() {
  }

  public void run() {
    if (!displayAnswer)
      drawCountdown();

    drawScore();
    drawCardPoints();
  }

  public void drawCountdown() {
    //Draw countdown bar
    float time=(millis()-prevTime)/1000;
    float x=0;
    setColor(time);
    stroke(0);
    rectMode(CORNER);
    if (correctAnswer) {
      time=maxTime-holdTime;
      x=map(holdTime, 0, maxTime, 0, width);
      rect(0, 0, x, 10);
    } 
    else {
      x=map(maxTime-time, 0, maxTime, 0, width);
      rect(0, 0, x, 10);
    }
    if (time>=maxTime) {
      prevTime=millis();
      displayAnswer=true;
      lives.remove(lives.size()-1);
    }

    textSize(12);
    textAlign(CENTER);
    fill(255);
    text(maxTime-time, width-40, 10);
  }

  public void setColor(float t) {
    //Set color of count down bar
    float green=0;
    float red=0;
    if (correctAnswer)
      t=maxTime-holdTime;
    if (maxTime-t<maxTime/2) {
      green=map(t, maxTime/2, maxTime, 255, 0);
      red=255;
    } 
    else {
      green=255;
      red=map(t, 0, maxTime/2, 0, 255);
    }
    fill(red, green, 0);
  }

  public void drawScore() {
    //Display score
    textSize(16);
    fill(255);
    textAlign(CENTER);
    text("SCORE: "+score, width/2, height-20);
  }

  public void drawCardPoints() {
    //Draw point dots based on midPoint cutoff and highPoint cutoff
    fill(255, 255, 0);
    stroke(0);
    if (answers.size()<=midPoint)
      scoreSys.multiplier=3;
    else if (answers.size()<=highPoint)
      scoreSys.multiplier=2;
    else  scoreSys.multiplier=1;

    for (int i=0; i<scoreSys.multiplier; i++)
      ellipse(width-20, 30+20*i, 10, 10);
  }
}

//-------------------------------------------------------------------

class Life {
  int s=50;
  int x;
  int y;
  int ident=0;
  boolean display=true;
  Life(int _ident) {
    ident=_ident;
  }

  public void run(int _x, int _y) {
    x=_x;
    y=_y;
    display();
  }

  public void display() {
    stroke(0);
    fill(0, 175, 225);
    rect(x, y, s, s);
  }

  public void loseLive(int i) {
    if (i==ident)
      display=false;
  }
}
public void mousePressed() {
  //Run click function for number objects and operations buttons
  for (int i=0; i<operation.length; i++)
    operation[i].click();
  for (int i=0; i<nums.size(); i++)
    nums.get(i).click();

  //Run click functions for all control buttons
  next.click();
  mode.click();
  undo.click();

  //If nothing is clicked clear selection
  if (!mouseOverNums()&&!mouseOverSymbols()) {
    if (solverMode)
      if (testForCompleteSolver()) {
        displayAnswer=true;
        compute();
      } 
      else {
        resetPermutations();
        displayAnswer=false;
      }
    selectedSymbol=0;
    selectedNum=0;
  }
  //if(gameOver)
  // restart();
}

public void keyPressed() {
  String hold="";
  if (solverMode&&selectedNum>0) {
    switch(key) {
    case '0':
      hold="0";
      break;
    case '1':
      hold="1";
      break;
    case '2':
      hold="2";
      break;
    case '3':
      hold="3";
      break;
    case '4':
      hold="4";
      break;
    case '5':
      hold="5";
      break;
    case '6':
      hold="6";
      break;
    case '7':
      hold="7";
      break;
    case '8':
      hold="8";
      break;
    case '9':
      hold="9";
      break;
    case BACKSPACE:
      if (nums.get(selectedNum-1).displayValue.length()>0)
        nums.get(selectedNum-1).displayValue=nums.get(selectedNum-1).displayValue.substring(0, nums.get(selectedNum-1).displayValue.length()-1);
      break;
    case TAB:
      selectedNum+=1;
      if (selectedNum>nums.size()) {
        if (testForCompleteSolver()) {
          displayAnswer=true;
          compute();
        }
      }
      break;
    case ENTER:
      selectedNum=0;
      if (testForCompleteSolver()) {
        compute();
        displayAnswer=true;
      } 
      else {
        displayAnswer=false;
        resetPermutations();
      }
      break;
    case CODED:
      switch(keyCode) {
      case LEFT:
        selectedNum-=1;
        break;
      case RIGHT:
        selectedNum+=1;
        break;
      case UP:
        nums.get(selectedNum-1).value+=1;
        nums.get(selectedNum-1).value2displayValue();
        break;
      case DOWN:
        nums.get(selectedNum-1).value-=1;
        nums.get(selectedNum-1).value2displayValue();
        break;
      }
      break;
    default:
      nums.get(selectedNum-1).displayValue="_";
      selectedNum=0;
      break;
    }

    if (selectedNum>0&&selectedNum<=nums.size()) {
      if (nums.get(selectedNum-1).displayValue.indexOf("_")>=0)
        nums.get(selectedNum-1).displayValue=hold;
      else
        nums.get(selectedNum-1).displayValue+=hold;
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "math24_2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
